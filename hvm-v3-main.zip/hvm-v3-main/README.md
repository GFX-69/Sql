# GET FILE INTO VPS ( Virtual Private Server )
---> ``git clone https://github.com/Himal0766/hvm-v3``
#  GET DREICTYL IN WHCIH THE HVM PANEL V3 IS
---> ``cd hvm-v3``

# DONE NOW DO ALL YOURSELF
